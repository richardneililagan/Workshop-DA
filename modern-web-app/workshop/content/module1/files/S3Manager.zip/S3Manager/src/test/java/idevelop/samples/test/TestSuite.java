package idevelop.samples.test;

import java.io.File;

import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.mockito.junit.MockitoJUnitRunner;

import com.amazonaws.services.s3.model.Region;

import idevelop.samples.AmazonS3Manager;

/**
 * A simple test harness for locally invoking your Lambda function handler.
 */
@RunWith(MockitoJUnitRunner.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TestSuite {

	final String bucketName = "idevelop-<yourname>-testsuite";
	
	@BeforeClass
    public static void setUp() {
		
		System.out.println("==================================");
		System.out.println("Starting Test Suite");
		System.out.println("==================================\n");
		System.out.println("Testing " + AmazonS3Manager.class.getName());
    }
	
    @Test
    public void test_A_CreateBucket() {

    	AmazonS3Manager s3manager = new AmazonS3Manager();
    	
	    	try
	    	{
	    		s3manager.CreateBucket(bucketName);
	    }
	    	catch(Exception ex)
	    	{
	    		System.out.println(ex.getMessage());
	    		throw ex;
	    	}
    }

    @Test
    public void test_B_ListBuckets() {

    	AmazonS3Manager s3manager = new AmazonS3Manager();
    	
    	s3manager.ListBuckets();
    }

    @Test
    public void test_C_ListBucketObjectsShouldBeEmpty() {

    	AmazonS3Manager s3manager = new AmazonS3Manager();
    	
    	Assert.assertEquals(0, s3manager.ListBucketObjects(bucketName)); 
    }

    @Test
    public void test_D_UploadObject() {

    	ClassLoader classLoader = getClass().getClassLoader();
    	File file = new File(classLoader.getResource("Puppy.jpg").getFile());
    	System.out.println(file.getAbsolutePath());

    	AmazonS3Manager s3manager = new AmazonS3Manager();
    	
    	s3manager.UploadObject(bucketName, "UploadTest.dat", file.toPath()); 
    }

    @Test
    public void test_E_DeleteObject() {

    	AmazonS3Manager s3manager = new AmazonS3Manager();
    	s3manager.DeleteObject(bucketName, "UploadTest.dat"); 
    }

    @Test
    public void test_Z_DeleteBucket() {

    	AmazonS3Manager s3manager = new AmazonS3Manager();
    	
    	s3manager.DeleteBucket(bucketName);
    }

}
