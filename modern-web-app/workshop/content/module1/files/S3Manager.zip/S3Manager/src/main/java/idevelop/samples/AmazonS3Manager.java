package idevelop.samples;

import java.nio.file.Path;
import java.util.List;
import java.util.concurrent.Executors;

import com.amazonaws.event.ProgressEvent;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.Bucket;
import com.amazonaws.services.s3.model.CreateBucketRequest;
import com.amazonaws.services.s3.model.DeleteBucketRequest;
import com.amazonaws.services.s3.model.DeleteObjectRequest;
import com.amazonaws.services.s3.model.ListObjectsV2Request;
import com.amazonaws.services.s3.model.ListObjectsV2Result;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.amazonaws.services.s3.transfer.TransferManager;
import com.amazonaws.services.s3.transfer.TransferManagerBuilder;
import com.amazonaws.services.s3.transfer.Upload;

public class AmazonS3Manager {
	
	private AmazonS3 s3 = null;
	
	public AmazonS3Manager()
	{
		this.s3 = AmazonS3ClientFactory.getClient();
	}
	
	public void UploadObject(
			String bucketName, 
			String keyName,
			Path   localFilePath
			)
	{
        TransferManagerBuilder transferManagerBuilder = TransferManagerBuilder.standard();
        transferManagerBuilder.setS3Client(s3);
        transferManagerBuilder.setExecutorFactory(() -> Executors.newFixedThreadPool(4));
        TransferManager tm = transferManagerBuilder.build();
        PutObjectRequest putObjectRequest = new PutObjectRequest(bucketName, keyName, localFilePath.toFile()); 
        Upload upload = tm.upload(putObjectRequest);
        System.out.println("Started upload of " + localFilePath.toString() + " to S3 location s3://" + bucketName + "/" + keyName);

        upload.addProgressListener((ProgressEvent progressEvent) -> {
        	//System.out.println("Progress: " + (progressEvent.getBytesTransferred() / progressEvent.getBytes() * 100) + "%");
        	System.out.printf("Progress: %.05f%%\n", upload.getProgress().getPercentTransferred() );        	
        });

        try {
            upload.waitForCompletion();
            System.out.println("Finished upload of " + localFilePath.toString());
        } catch (Exception e) {
        	System.out.println("Failed to upload file: " + e.getLocalizedMessage());
        }

        tm.shutdownNow();
        
        System.out.println("Uploaded file to bucket " + bucketName + ".");
	}
	
	public void CreateBucket(
			String bucketName) 
	{       
        CreateBucketRequest request = new CreateBucketRequest(
        		bucketName
                );
    
        this.s3.createBucket(request);
        System.out.println("Created bucket " + bucketName + ".");
    }
	
	public void ListBuckets()
	{
		List<Bucket> buckets = this.s3.listBuckets();
        for (Bucket bucket : buckets) {
            System.out.println("     " + bucket.getName() + ": Created on " + bucket.getCreationDate());
        }
	}
	
	public int ListBucketObjects(
			String bucketName) 
	{       
		int itemCount = 0;
		ListObjectsV2Request listObjectsRequest = new ListObjectsV2Request();
        listObjectsRequest.setBucketName(bucketName);
        ListObjectsV2Result result = this.s3.listObjectsV2(listObjectsRequest);

        for (S3ObjectSummary summary : result.getObjectSummaries()) {
            System.out.println(summary.getKey() + "  [" + summary.getSize() + " bytes]");
            itemCount++;
        }    
        
        return itemCount;
	}
	
	public void DeleteBucket(
			String bucketName) 
	{       
        DeleteBucketRequest deleteBucketRequest = new DeleteBucketRequest(bucketName);
        this.s3.deleteBucket(deleteBucketRequest);

        System.out.println("Deleted bucket " + bucketName + ".");
    }

	public void DeleteObject(
			String bucketName,
			String keyName
			) 
	{       
        DeleteObjectRequest deleteObjectRequest = new DeleteObjectRequest(bucketName, keyName);
        this.s3.deleteObject(deleteObjectRequest);

        System.out.println("Deleted object " + bucketName + "/" + keyName);
    }

}


