package idevelop.samples;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

import com.amazonaws.services.s3.model.Region;

public class Application {

	public static int menu(String bucketName) {
	
	    int selection;
	    Scanner input = new Scanner(System.in);

        System.out.println("-------------------------");
        System.out.println("Main Menu");
        System.out.println("-------------------------\n");
        System.out.println("0 - Quit");
        System.out.println("1 - Set Bucket Name (" + bucketName + ")");
        System.out.println("2 - Create Bucket (" + bucketName + ")");
        System.out.println("3 - Delete Bucket (" + bucketName + ")");
        System.out.println("4 - List All Buckets");
        System.out.println("5 - Upload file to Bucket (" + bucketName + ")");
        System.out.println("6 - List Bucket Objects (" + bucketName + ")");
        System.out.println("7 - Delete Object in Bucket (" + bucketName + ")");
	    	
	    selection = input.nextInt();
	    return selection;    
	}
	
	public static void main(String[] args) {

		
        System.out.println("===========================================");
        System.out.println("Welcome to iDevelop<AWS>!");
        System.out.println("===========================================");
        System.out.println("\nS3Tester starting!\n");

        AmazonS3Manager s3manager = new AmazonS3Manager();
        String bucketName = "idevelop-<yourname>-testsuite";
        
		int menuChoice = -1;
		
		while (menuChoice != 0) {
			
			try
			{
				menuChoice = menu(bucketName);
				
				Scanner input = new Scanner(System.in);
				
				switch ( menuChoice ) {
							
					case 0:
						System.out.println("\nExiting!");
						break;
					
					case 1:
						System.out.print("\nPlease enter bucketName: ");
						bucketName = input.nextLine();
						System.out.println("\nOk, bucketName set to " + bucketName);
						break;
				
					case 2:
						System.out.println("\nCreating S3 bucket '" + bucketName + "'...");
						s3manager.CreateBucket(bucketName);
						System.out.println("     done!");
						break;

					case 3:
						System.out.println("\nDeleting S3 bucket '" + bucketName + "'...");
						s3manager.DeleteBucket(bucketName);
						System.out.println("     done!");
						break;

					case 4:
						System.out.println("\nListing S3 buckets in your account...");
						s3manager.ListBuckets();
						System.out.println("\n\n     done!");
						break;

					case 5:
						System.out.print("\nWhat is the local file path (full path to file)? ");
						String filePath = input.nextLine();
						
						Path fsPath = Paths.get(filePath);
 						System.out.print("What keyName to use in the bucket (" + fsPath.getFileName() + ")? ");
 						String keyName = input.nextLine();
						if ( keyName.equals("") )
							keyName = fsPath.getFileName().toString();
						
						s3manager.UploadObject(bucketName, keyName, fsPath);
						System.out.println("\n\n     done!");
						break;

					case 6:
						System.out.println("\nListing objects in bucket '" + bucketName + "' ...");
						s3manager.ListBucketObjects(bucketName);
						System.out.println("\n\n     done!");
						break;
						
					case 7:
						System.out.print("What keyName to delete in the bucket? ");
 						String keyNameToDelete = input.nextLine();

 						System.out.println("\nDeleting object in bucket " + bucketName + "/" + keyNameToDelete);
						s3manager.DeleteObject(bucketName, keyNameToDelete);
						System.out.println("\n\n     done!");
						break;

				}
				
			}
			catch(Exception ex)
			{
				System.out.println("\n===========================================");
				System.out.println("EXCEPTION: " + ex.getMessage());
				System.out.println("===========================================\n");
			}
		}
			
        

        
    }
}

