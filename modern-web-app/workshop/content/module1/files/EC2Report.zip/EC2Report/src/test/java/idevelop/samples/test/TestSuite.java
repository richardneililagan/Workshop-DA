package idevelop.samples.test;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import idevelop.samples.EC2Manager;

/**
 * A simple test harness for locally invoking your Lambda function handler.
 */
@RunWith(MockitoJUnitRunner.class)
public class TestSuite {

	@Before
    public void setUp() {
		
		System.out.println("==================================");
		System.out.println("Starting Test Suite");
		System.out.println("==================================\n");
		System.out.println("Testing " + EC2Manager.class.getName());
    }
	
    @Test
    public void testEC2Report() {

    	EC2Manager mgr = new EC2Manager();
    	Assert.assertTrue(mgr.ReportEC2Environment());
    }
}
