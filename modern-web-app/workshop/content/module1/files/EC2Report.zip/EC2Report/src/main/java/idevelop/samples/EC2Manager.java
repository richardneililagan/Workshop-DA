package idevelop.samples;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.amazonaws.AmazonClientException;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.codedeploy.model.InstanceType;
import com.amazonaws.services.ec2.AmazonEC2;
import com.amazonaws.services.ec2.AmazonEC2ClientBuilder;
import com.amazonaws.services.ec2.model.AvailabilityZone;
import com.amazonaws.services.ec2.model.DescribeAvailabilityZonesResult;
import com.amazonaws.services.ec2.model.DescribeInstancesResult;
import com.amazonaws.services.ec2.model.Instance;
import com.amazonaws.services.ec2.model.InstanceNetworkInterfaceSpecification;
import com.amazonaws.services.ec2.model.Reservation;
import com.amazonaws.services.ec2.model.RunInstancesRequest;
import com.amazonaws.services.ec2.model.RunInstancesResult;

public class EC2Manager {

	private AmazonEC2 ec2;
	/*
     * The ProfileCredentialsProvider will return your [default]
     * credential profile by reading from the credentials file located at
     * (~/.aws/credentials).
     */
    private AWSCredentials credentials = null;

	public boolean ReportEC2Environment() {

		boolean succeeded = false;

        try {
            credentials = new ProfileCredentialsProvider("devaxacademy").getCredentials();
        } catch (Exception e) {
            throw new AmazonClientException(
                    "Cannot load the credentials from the credential profiles file. " +
                    "Please make sure that your credentials file is at the correct " +
                    "location (~/.aws/credentials), and is in valid format.",
                    e);
        }

        System.out.println("Creating EC2 Client...");
        ec2 = AmazonEC2ClientBuilder
        		.standard()
        		.withRegion(Regions.AP_SOUTHEAST_2)
        		.withCredentials(new AWSStaticCredentialsProvider(credentials))
        		.build();
        System.out.println("     done!");


        DescribeAvailabilityZonesResult availabilityZonesResult = ec2.describeAvailabilityZones();
        System.out.println("You have access to " + availabilityZonesResult.getAvailabilityZones().size() +
                " Availability Zones:");

        for ( AvailabilityZone zone : availabilityZonesResult.getAvailabilityZones() ) {
        	System.out.println("     " + zone.getZoneName());
        }

        DescribeInstancesResult describeInstancesRequest = ec2.describeInstances();
        List<Reservation> reservations = describeInstancesRequest.getReservations();
        Set<Instance> instances = new HashSet<Instance>();

        for (Reservation reservation : reservations) {
            instances.addAll(reservation.getInstances());
        }

        System.out.println("You have " + instances.size() + " Amazon EC2 instance(s) registered:");

        for ( Instance instance : instances ) {
        	System.out.print("<" + instance.getState().getName() + "> [");
        	System.out.print(instance.getPlacement().getAvailabilityZone() + "] ");
        	System.out.print(instance.getInstanceId() + " ");
        	System.out.print(instance.getInstanceType() + " @ ");
        	System.out.println(instance.getPrivateIpAddress());
        }
        
        System.out.println("Creating EC2 Server...");
        RunInstancesRequest runInstancesRequest =
        		   new RunInstancesRequest();

        runInstancesRequest.withImageId("ami-fd9cecc7")
        		           .withInstanceType("t2.small")
        		           .withMinCount(1)
        		           .withMaxCount(1)
        		           .withKeyName("devaxacademy")
        		           .withNetworkInterfaces(new InstanceNetworkInterfaceSpecification()
        	                        .withAssociatePublicIpAddress(true)
        	                        .withDeviceIndex(0)
        	                        .withSubnetId("subnet-0b143da2fdfe1faec")
        	                        .withGroups("sg-0703ecb992a7247c7"));

        		                   
        RunInstancesResult result = ec2.runInstances(runInstancesRequest);
        
        succeeded = true;
        return succeeded;
	}
}
